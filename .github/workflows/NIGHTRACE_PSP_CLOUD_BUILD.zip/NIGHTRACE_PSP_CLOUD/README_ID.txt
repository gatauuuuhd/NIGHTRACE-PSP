NIGHTRACE — PSP Homebrew starter + cloud build workflow

This ZIP contains source code and a GitHub Actions workflow. It is NOT a prebuilt EBOOT.PBP.
The workflow uses the PSPDEV project's published Docker image to compile the project in GitHub Actions.

BUILD FROM AN ANDROID PHONE:
1. Download/extract this ZIP.
2. In a browser, sign in to GitHub and create a NEW PUBLIC repository named NIGHTRACE-PSP.
3. Upload the files and folders from inside NIGHTRACE_PSP_CLOUD to the repository, preserving the path:
   .github/workflows/build.yml
   Makefile
   main.c
   README_ID.txt
   build.sh
4. Open the repository's Actions tab.
5. Select "Build NIGHTRACE PSP", then press "Run workflow".
6. Wait for the run to finish. Green means success; red means build failed.
7. Open the successful run and download the artifact named NIGHTRACE-EBOOT. Extract it to get EBOOT.PBP.
8. On Android storage, create:
   PSP/GAME/NIGHTRACE/
   Put EBOOT.PBP inside that folder, then open PPSSPP and browse to it.

If GitHub blocks Actions for a new repository, enable Actions in the repository settings.
Do not add passwords, API keys, or other secrets to the repository.
This workflow has not been run from this chat, so a successful build and PPSSPP compatibility are not yet verified.

CONTROLS:
- D-pad left/right: steer
- Cross: restart after crash
- Start: exit

This is a small text-mode racing prototype, not a 3D racing game.
Official PSPDEV project: https://github.com/pspdev/pspdev
