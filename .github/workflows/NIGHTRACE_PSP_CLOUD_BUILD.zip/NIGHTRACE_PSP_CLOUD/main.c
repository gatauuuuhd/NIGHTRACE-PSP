#include <pspkernel.h>
#include <pspdebug.h>
#include <pspctrl.h>
#include <stdio.h>
#include <stdlib.h>

PSP_MODULE_INFO("NIGHTRACE", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);

static int player_lane = 1;
static int score = 0;
static int tick = 0;
static int obstacle_lane = 1;
static int obstacle_y = 0;

static void draw_scene(void) {
    int y, x;
    pspDebugScreenSetXY(0, 0);
    pspDebugScreenSetTextColor(0xFF44FF44);
    pspDebugScreenPrintf("======================================\n");
    pspDebugScreenPrintf("          NIGHTRACE // PSP            \n");
    pspDebugScreenPrintf("======================================\n");
    pspDebugScreenSetTextColor(0xFFFFFFFF);
    pspDebugScreenPrintf(" SCORE: %-6d      SPEED: %d\n\n", score, 1 + score / 100);

    for (y = 0; y < 13; y++) {
        pspDebugScreenPrintf("       ");
        for (x = 0; x < 3; x++) {
            pspDebugScreenPrintf("|");
            if (y == obstacle_y && x == obstacle_lane) {
                pspDebugScreenSetTextColor(0xFF4444FF);
                pspDebugScreenPrintf(" [X] ");
                pspDebugScreenSetTextColor(0xFFFFFFFF);
            } else if (y == 12 && x == player_lane) {
                pspDebugScreenSetTextColor(0xFF44FFFF);
                pspDebugScreenPrintf(" [A] ");
                pspDebugScreenSetTextColor(0xFFFFFFFF);
            } else {
                pspDebugScreenPrintf("  .  ");
            }
        }
        pspDebugScreenPrintf("|\n");
    }
    pspDebugScreenSetTextColor(0xFF44FF44);
    pspDebugScreenPrintf("\n D-PAD LEFT/RIGHT: steer   START: quit\n");
    pspDebugScreenPrintf(" Avoid [X] cars. Pass them to score!\n");
    pspDebugScreenSetTextColor(0xFFFFFFFF);
}

int main(void) {
    SceCtrlData pad;
    int old_buttons = 0;
    int game_over = 0;
    int delay = 180000;

    pspDebugScreenInit();
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_DIGITAL);

    while (1) {
        sceCtrlReadBufferPositive(&pad, 1);
        if (pad.Buttons & PSP_CTRL_START) break;

        if (!game_over) {
            if ((pad.Buttons & PSP_CTRL_LEFT) && !(old_buttons & PSP_CTRL_LEFT))
                if (player_lane > 0) player_lane--;
            if ((pad.Buttons & PSP_CTRL_RIGHT) && !(old_buttons & PSP_CTRL_RIGHT))
                if (player_lane < 2) player_lane++;

            tick++;
            if (tick % 7 == 0) {
                obstacle_y++;
                if (obstacle_y > 12) {
                    obstacle_y = 0;
                    obstacle_lane = rand() % 3;
                    score += 10;
                    if (delay > 70000) delay -= 1500;
                }
            }

            if (obstacle_y == 12 && obstacle_lane == player_lane) game_over = 1;
            pspDebugScreenClear();
            draw_scene();
        } else {
            pspDebugScreenClear();
            pspDebugScreenSetTextColor(0xFF4444FF);
            pspDebugScreenSetXY(7, 5);
            pspDebugScreenPrintf(" CRASH! GAME OVER ");
            pspDebugScreenSetTextColor(0xFFFFFFFF);
            pspDebugScreenSetXY(4, 8);
            pspDebugScreenPrintf("Final score: %d", score);
            pspDebugScreenSetXY(2, 11);
            pspDebugScreenPrintf("Press CROSS to race again");
            pspDebugScreenSetXY(2, 12);
            pspDebugScreenPrintf("Press START to exit");
            if (pad.Buttons & PSP_CTRL_CROSS) {
                player_lane = 1; score = 0; tick = 0;
                obstacle_lane = rand() % 3; obstacle_y = 0;
                delay = 180000; game_over = 0;
            }
        }
        old_buttons = pad.Buttons;
        sceDisplayWaitVblankStart();
        sceKernelDelayThread(delay);
    }
    sceKernelExitGame();
    return 0;
}
