#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
if ! command -v psp-gcc >/dev/null 2>&1 || ! command -v psp-config >/dev/null 2>&1; then
  echo "PSP SDK belum ditemukan. Untuk build lewat cloud, ikuti README_ID.txt."
  exit 1
fi
make clean
make
echo "Build selesai: $(pwd)/EBOOT.PBP"
